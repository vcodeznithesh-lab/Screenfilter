"""
Main processing pipeline for Screenshot Privacy Filter.
Handles OCR, NER, face detection, QR detection, and redaction.
"""

import cv2
import numpy as np
import re
from typing import List, Dict, Any, Tuple, Optional
from PIL import Image
import logging
from utils import (
    merge_overlapping_boxes, 
    preprocess_image, 
    expand_bbox, 
    bbox_from_points,
    mask_sensitive_text
)

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class PrivacyDetector:
    """Main class for detecting and redacting sensitive information in screenshots."""
    
    def __init__(self, use_spacy: bool = True, use_mtcnn: bool = True):
        """
        Initialize detector with optional heavy dependencies.
        
        Args:
            use_spacy: Whether to load spaCy for NER
            use_mtcnn: Whether to load MTCNN for face detection
        """
        self.use_spacy = use_spacy
        self.use_mtcnn = use_mtcnn
        
        # Initialize spaCy
        self.nlp = None
        if use_spacy:
            try:
                import spacy
                try:
                    self.nlp = spacy.load("en_core_web_sm")
                    logger.info("spaCy model loaded successfully")
                except OSError:
                    logger.warning("spaCy model not found. Run: python -m spacy download en_core_web_sm")
            except ImportError:
                logger.warning("spaCy not available, NER will be limited to regex")
        
        # Initialize face detector
        self.face_detector = None
        if use_mtcnn:
            try:
                from mtcnn import MTCNN
                self.face_detector = MTCNN()
                logger.info("MTCNN face detector loaded")
            except Exception as e:
                logger.warning(f"MTCNN not available: {e}. Using OpenCV cascade")
                try:
                    self.face_detector = cv2.CascadeClassifier(
                        cv2.data.haarcascades + 'haarcascade_frontalface_default.xml'
                    )
                except Exception as e2:
                    logger.error(f"Face detection unavailable: {e2}")
        
        # Regex patterns for sensitive data
        self.patterns = {
            'email': re.compile(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'),
            'phone': re.compile(r'(\+?\d{1,3}[-.\s]?)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}|\+?\d{10,15}'),
            'currency': re.compile(r'(?:₹|Rs\.?|USD|\$|€|£)\s*[\d,]+(?:\.\d{2})?'),
            'amount': re.compile(r'\b\d{1,3}(?:,\d{3})*(?:\.\d{2})?\s*(?:USD|EUR|GBP|INR|Rs|₹)?\b'),
            'transaction_id': re.compile(r'\b(?:TXN|REF|ID|ORDER)[-:]?\s*[A-Z0-9]{6,}\b', re.IGNORECASE),
            'credit_card': re.compile(r'\b\d{4}[\s-]?\d{4}[\s-]?\d{4}[\s-]?\d{4}\b'),
            'ssn': re.compile(r'\b\d{3}-\d{2}-\d{4}\b'),
        }
        
        # Context keywords that indicate nearby PII
        self.context_keywords = [
            'contact', 'phone', 'email', 'address', 'name', 'account',
            'balance', 'amount', 'payment', 'transaction', 'id', 'reference'
        ]
    
    def detect_text_with_ocr(self, image: np.ndarray) -> List[Dict[str, Any]]:
        """
        Perform OCR to extract text and bounding boxes.
        Falls back to pytesseract if EasyOCR is not available.
        
        Args:
            image: Input image as numpy array
        
        Returns:
            List of detected text items with bboxes
        """
        detections = []
        
        try:
            import pytesseract
            from PIL import Image as PILImage
            
            # Convert to PIL for pytesseract
            pil_image = PILImage.fromarray(cv2.cvtColor(image, cv2.COLOR_BGR2RGB))
            
            # Get detailed data
            data = pytesseract.image_to_data(pil_image, output_type=pytesseract.Output.DICT)
            
            n_boxes = len(data['text'])
            logger.info(f"OCR processing {n_boxes} text boxes from pytesseract")
            
            for i in range(n_boxes):
                text = data['text'][i].strip()
                
                # Skip empty text
                if not text:
                    continue
                
                # Get confidence, handle -1 (no confidence) case
                try:
                    conf = int(data['conf'][i])
                except (ValueError, TypeError):
                    conf = 0
                
                # Use lower threshold for better detection
                if conf > 20 or (len(text) > 3 and conf >= 0):
                    x, y, w, h = data['left'][i], data['top'][i], data['width'][i], data['height'][i]
                    
                    # Ensure valid bbox dimensions
                    if w > 0 and h > 0:
                        detections.append({
                            'text': text,
                            'bbox': [x, y, x + w, y + h],
                            'confidence': conf / 100.0 if conf > 0 else 0.5
                        })
                        logger.debug(f"OCR found: '{text[:20]}...' at bbox {[x, y, x+w, y+h]} conf={conf}")
            
            logger.info(f"OCR detected {len(detections)} valid text regions")
            if len(detections) == 0:
                logger.warning("OCR detected no text! Image may be too noisy or empty.")
            
        except Exception as e:
            logger.error(f"OCR failed: {e}", exc_info=True)
        
        return detections
    
    def detect_sensitive_patterns(self, ocr_results: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Detect sensitive information using regex patterns.
        
        Args:
            ocr_results: List of OCR detections with text and bbox
        
        Returns:
            List of sensitive detections
        """
        sensitive_items = []
        
        if not ocr_results:
            logger.warning("Pattern detection: No OCR results to process")
            return sensitive_items
        
        logger.info(f"Pattern detection: Scanning {len(ocr_results)} OCR text items")
        
        for item in ocr_results:
            text = item['text']
            
            # Check each pattern
            for pattern_name, pattern in self.patterns.items():
                if pattern.search(text):
                    masked_text = mask_sensitive_text(text)
                    sensitive_items.append({
                        'type': pattern_name,
                        'text': masked_text,
                        'bbox': item['bbox'],
                        'confidence': item.get('confidence', 0.8)
                    })
                    logger.info(f"Regex match: {pattern_name} pattern matched '{masked_text}' at bbox {item['bbox']}")
                    break  # Only match first pattern per text item
        
        logger.info(f"Pattern detection: Found {len(sensitive_items)} sensitive items")
        return sensitive_items
    
    def detect_entities_with_ner(self, ocr_results: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Detect named entities (names, locations) using spaCy NER.
        
        Args:
            ocr_results: List of OCR detections
        
        Returns:
            List of entity detections
        """
        if not self.nlp:
            return []
        
        entities = []
        
        if not ocr_results:
            logger.warning("NER: No OCR results to process")
            return entities
        
        # Build full text and character-to-box mapping simultaneously
        # This ensures exact alignment with how spaCy sees the text
        text_parts = []
        text_to_box_map = []
        char_pos = 0
        
        for idx, item in enumerate(ocr_results):
            text = item['text']
            
            # Record the exact character range for this OCR item
            start_pos = char_pos
            end_pos = char_pos + len(text)
            
            text_to_box_map.append({
                'start': start_pos,
                'end': end_pos,
                'bbox': item['bbox'],
                'text': text,
                'index': idx
            })
            
            text_parts.append(text)
            char_pos = end_pos
            
            # Add space separator (except after last item)
            if idx < len(ocr_results) - 1:
                text_parts.append(' ')
                char_pos += 1  # Account for the space
        
        # Reconstruct the exact text that spaCy will process
        full_text = ''.join(text_parts)
        logger.info(f"NER processing {len(ocr_results)} OCR items, text length: {len(full_text)}")
        logger.debug(f"NER text sample: {full_text[:100]}...")
        
        # Run spaCy NER
        doc = self.nlp(full_text)
        
        # Map entities back to OCR bboxes using precise character positions
        for ent in doc.ents:
            if ent.label_ in ['PERSON', 'GPE', 'LOC', 'ORG']:
                ent_start = ent.start_char
                ent_end = ent.end_char
                
                # Find all OCR boxes that overlap with this entity's character range
                # Use strict comparisons to handle boundary cases correctly
                # (ent.end_char is exclusive, so we need > and < not >= and <=)
                matched_boxes = []
                for box_map in text_to_box_map:
                    # Overlap if entity ends after box starts AND entity starts before box ends
                    if ent_end > box_map['start'] and ent_start < box_map['end']:
                        matched_boxes.append(box_map['bbox'])
                        logger.debug(f"NER '{ent.text}' [{ent_start}:{ent_end}] overlaps box '{box_map['text']}' [{box_map['start']}:{box_map['end']}]")
                
                if matched_boxes:
                    # Create detection for each matched box to handle multi-token entities
                    for bbox in matched_boxes:
                        entities.append({
                            'type': f'ner_{ent.label_.lower()}',
                            'text': mask_sensitive_text(ent.text) or '***',  # Fallback masking
                            'bbox': bbox,
                            'confidence': 0.7
                        })
                    logger.info(f"NER detected {ent.label_}: {mask_sensitive_text(ent.text) or '***'} ({len(matched_boxes)} boxes)")
                else:
                    logger.warning(f"NER entity '{ent.text}' [{ent_start}:{ent_end}] found no matching OCR boxes")
        
        logger.info(f"NER total: Found {len(entities)} entity detections")
        return entities
    
    def detect_faces(self, image: np.ndarray) -> List[Dict[str, Any]]:
        """
        Detect faces in the image.
        
        Args:
            image: Input image as numpy array
        
        Returns:
            List of face detections with bboxes
        """
        faces = []
        
        try:
            if isinstance(self.face_detector, cv2.CascadeClassifier):
                # OpenCV cascade classifier
                gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
                face_rects = self.face_detector.detectMultiScale(
                    gray, scaleFactor=1.1, minNeighbors=5, minSize=(30, 30)
                )
                
                for (x, y, w, h) in face_rects:
                    faces.append({
                        'type': 'face',
                        'text': '',
                        'bbox': [x, y, x + w, y + h],
                        'confidence': 0.8
                    })
            
            elif self.face_detector:
                # MTCNN detector
                rgb_image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
                detections = self.face_detector.detect_faces(rgb_image)
                
                for detection in detections:
                    x, y, w, h = detection['box']
                    faces.append({
                        'type': 'face',
                        'text': '',
                        'bbox': [x, y, x + w, y + h],
                        'confidence': detection['confidence']
                    })
            
            logger.info(f"Detected {len(faces)} faces")
            
        except Exception as e:
            logger.error(f"Face detection failed: {e}")
        
        return faces
    
    def detect_qr_codes(self, image: np.ndarray) -> List[Dict[str, Any]]:
        """
        Detect QR codes and barcodes.
        
        Args:
            image: Input image as numpy array
        
        Returns:
            List of QR/barcode detections
        """
        codes = []
        
        try:
            from pyzbar.pyzbar import decode
            
            # Decode QR codes and barcodes
            decoded_objects = decode(image)
            
            for obj in decoded_objects:
                # Get bounding box
                points = obj.polygon
                if len(points) == 4:
                    bbox = bbox_from_points([(p.x, p.y) for p in points])
                else:
                    x, y, w, h = obj.rect
                    bbox = [x, y, x + w, y + h]
                
                codes.append({
                    'type': f'qr_{obj.type.lower()}',
                    'text': '',  # Don't store decoded content for privacy
                    'bbox': bbox,
                    'confidence': 1.0
                })
            
            logger.info(f"Detected {len(codes)} QR/barcodes")
            
        except Exception as e:
            logger.error(f"QR detection failed: {e}")
        
        return codes
    
    def redact_regions(
        self, 
        image: np.ndarray, 
        detections: List[Dict[str, Any]], 
        method: str = 'pixelate',
        block_size: int = 10
    ) -> np.ndarray:
        """
        Redact detected regions using specified method.
        
        Args:
            image: Input image
            detections: List of detections with bboxes
            method: Redaction method ('pixelate', 'blur', 'black')
            block_size: Size of pixelation blocks
        
        Returns:
            Redacted image
        """
        redacted = image.copy()
        
        for detection in detections:
            bbox = detection['bbox']
            x1, y1, x2, y2 = [int(coord) for coord in bbox]
            
            # Ensure coordinates are within image bounds
            height, width = image.shape[:2]
            x1, y1 = max(0, x1), max(0, y1)
            x2, y2 = min(width, x2), min(height, y2)
            
            if x2 <= x1 or y2 <= y1:
                continue
            
            region = redacted[y1:y2, x1:x2]
            
            if method == 'pixelate':
                # Pixelation
                h, w = region.shape[:2]
                if h > 0 and w > 0:
                    # Shrink and then expand to create pixelation effect
                    temp = cv2.resize(region, (max(1, w // block_size), max(1, h // block_size)), 
                                     interpolation=cv2.INTER_LINEAR)
                    pixelated = cv2.resize(temp, (w, h), interpolation=cv2.INTER_NEAREST)
                    redacted[y1:y2, x1:x2] = pixelated
            
            elif method == 'blur':
                # Gaussian blur
                blurred = cv2.GaussianBlur(region, (51, 51), 0)
                redacted[y1:y2, x1:x2] = blurred
            
            else:  # black
                # Black rectangle
                redacted[y1:y2, x1:x2] = 0
        
        logger.info(f"Redacted {len(detections)} regions using {method}")
        return redacted
    
    def process_image(
        self, 
        image: np.ndarray, 
        detection_config: Optional[Dict[str, bool]] = None,
        redaction_method: str = 'pixelate'
    ) -> Tuple[np.ndarray, List[Dict[str, Any]]]:
        """
        Main pipeline to process image and detect/redact sensitive information.
        
        Args:
            image: Input image as numpy array
            detection_config: Dict specifying which detections to run
            redaction_method: Method for redaction
        
        Returns:
            Tuple of (redacted_image, list of detections)
        """
        if detection_config is None:
            detection_config = {
                'text': True,
                'faces': True,
                'qr_codes': True,
                'ner': True
            }
        
        # Preprocess
        processed = preprocess_image(image)
        
        all_detections = []
        
        # OCR
        if detection_config.get('text', True):
            ocr_results = self.detect_text_with_ocr(processed)
            
            # Regex-based detection
            sensitive_text = self.detect_sensitive_patterns(ocr_results)
            all_detections.extend(sensitive_text)
            
            # NER-based detection
            if detection_config.get('ner', True):
                entities = self.detect_entities_with_ner(ocr_results)
                all_detections.extend(entities)
        
        # Face detection
        if detection_config.get('faces', True):
            faces = self.detect_faces(processed)
            all_detections.extend(faces)
        
        # QR code detection
        if detection_config.get('qr_codes', True):
            qr_codes = self.detect_qr_codes(processed)
            all_detections.extend(qr_codes)
        
        # Merge overlapping detections
        merged_detections = merge_overlapping_boxes(all_detections)
        
        # Redact
        redacted_image = self.redact_regions(processed, merged_detections, method=redaction_method)
        
        logger.info(f"Processing complete: {len(merged_detections)} regions redacted")
        
        return redacted_image, merged_detections
