# Screenshot Privacy Filter 🔒

A web application that automatically detects and redacts sensitive information from screenshots using OCR, computer vision, and NLP techniques.

## Features

- **Multi-layer Detection Pipeline**:
  - 📧 **Text Pattern Detection**: Emails, phone numbers, credit cards, SSN, currency amounts, transaction IDs
  - 👤 **Face Detection**: Automatically detect and redact faces using MTCNN or OpenCV
  - 📱 **QR/Barcode Detection**: Detect and redact QR codes and barcodes
  - 🏷️ **Named Entity Recognition**: Detect person names and locations using spaCy NER

- **Flexible Redaction Methods**:
  - Pixelation (default)
  - Gaussian blur
  - Black box overlay

- **Privacy-First Design**:
  - No permanent storage of uploaded screenshots
  - Temporary file handling with automatic cleanup
  - Sensitive text is masked in logs

- **Interactive Web UI**:
  - Drag & drop file upload
  - Before/after comparison
  - Toggle individual detection types
  - Download redacted images
  - Real-time detection statistics

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                      Web Interface                          │
│  (Upload → Configure → Preview → Download)                  │
└─────────────────────┬───────────────────────────────────────┘
                      │
                      ▼
┌─────────────────────────────────────────────────────────────┐
│                   FastAPI Backend                           │
│              POST /api/redact endpoint                      │
└─────────────────────┬───────────────────────────────────────┘
                      │
                      ▼
┌─────────────────────────────────────────────────────────────┐
│              Privacy Detection Pipeline                     │
├─────────────────────────────────────────────────────────────┤
│  1. Preprocessing (resize, normalize)                       │
│  2. OCR (pytesseract) → text + bounding boxes              │
│  3. Regex Pattern Matching → sensitive text                 │
│  4. spaCy NER → person names, locations                     │
│  5. Face Detection (MTCNN/OpenCV) → face bboxes            │
│  6. QR Detection (pyzbar) → QR/barcode bboxes              │
│  7. Bbox Merging (IoU-based)                               │
│  8. Redaction (pixelate/blur/black)                        │
└─────────────────────────────────────────────────────────────┘
```

## Installation

### Prerequisites
- Python 3.10 or higher
- Tesseract OCR (for text detection)

### Install Tesseract OCR

**Ubuntu/Debian:**
```bash
sudo apt-get update
sudo apt-get install tesseract-ocr libtesseract-dev
```

**macOS:**
```bash
brew install tesseract
```

**Windows:**
Download from: https://github.com/UB-Mannheim/tesseract/wiki

### Install Python Dependencies

```bash
pip install -r requirements.txt
```

### Download spaCy Model

```bash
python -m spacy download en_core_web_sm
```

## Usage

### Running the Server

Start the FastAPI server:

```bash
uvicorn app:app --host 0.0.0.0 --port 5000 --reload
```

Or using Python directly:

```bash
python app.py
```

The application will be available at: `http://localhost:5000`

### Using the Web Interface

1. Open your browser and navigate to `http://localhost:5000`
2. Drag and drop a screenshot or click to upload
3. Select which types of information to detect
4. Choose a redaction method (pixelate, blur, or black box)
5. Click "Process Screenshot"
6. Review the results and download the redacted image

### Using the API

**Upload and Redact Screenshot:**

```bash
curl -X POST "http://localhost:5000/api/redact" \
  -F "file=@screenshot.png" \
  -F "detect_text=true" \
  -F "detect_faces=true" \
  -F "detect_qr=true" \
  -F "detect_ner=true" \
  -F "redaction_method=pixelate" \
  -F "return_image=false"
```

**Response:**
```json
{
  "success": true,
  "detections": [
    {
      "type": "email",
      "bbox": [100, 150, 300, 180],
      "confidence": 0.95
    },
    {
      "type": "phone",
      "bbox": [100, 200, 280, 230],
      "confidence": 0.90
    }
  ],
  "num_detections": 2,
  "redacted_image": "data:image/png;base64,..."
}
```

**Download Redacted Image Directly:**

```bash
curl -X POST "http://localhost:5000/api/redact" \
  -F "file=@screenshot.png" \
  -F "return_image=true" \
  --output redacted.png
```

**Health Check:**

```bash
curl http://localhost:5000/health
```

## Testing

### Run Unit Tests

```bash
pytest tests/test_pipeline.py -v
```

### Generate Synthetic Test Data

```bash
python sample_data/generate_synthetic.py
```

This creates sample screenshots in `sample_data/` with embedded sensitive information for testing.

### Test with Sample Data

```bash
curl -X POST "http://localhost:5000/api/redact" \
  -F "file=@sample_data/screenshot_mixed.png" \
  -F "return_image=true" \
  --output redacted_sample.png
```

## Detection Patterns

### Regex Patterns

- **Email**: Standard email format (user@domain.com)
- **Phone**: Multiple formats including international (+1-555-123-4567, (555) 123-4567, etc.)
- **Currency**: Multiple symbols (₹, Rs, USD, $, €, £) with amounts
- **Credit Card**: 16-digit numbers with optional separators
- **SSN**: XXX-XX-XXXX format
- **Transaction ID**: Patterns like TXN-XXXXXX, REF-XXXXXX, ORDER-XXXXXX

### Named Entity Recognition (NER)

- PERSON: Person names
- GPE: Geopolitical entities (cities, countries)
- ORG: Organizations
- LOC: Locations

## Configuration

### Detection Options

All detection types can be toggled via the API or web interface:

- `detect_text`: Enable/disable text pattern detection
- `detect_faces`: Enable/disable face detection
- `detect_qr`: Enable/disable QR/barcode detection
- `detect_ner`: Enable/disable NER entity detection

### Redaction Methods

- **pixelate**: Pixelate sensitive regions (default, block_size=10)
- **blur**: Apply Gaussian blur
- **black**: Solid black rectangle overlay

### Performance Settings

- Maximum file size: 5 MB
- Image auto-resize: Images larger than 1080px are automatically resized
- Bbox merge threshold: IoU > 0.1
- Bbox padding: 6 pixels (default)

## File Structure

```
screenshot-privacy-filter/
├── app.py                      # FastAPI server and endpoints
├── processor.py                # Detection and redaction pipeline
├── utils.py                    # Utility functions (bbox ops, etc.)
├── requirements.txt            # Python dependencies
├── README.md                   # Documentation
├── .gitignore                  # Git ignore file
├── static/                     # Frontend files
│   ├── index.html             # Web interface
│   ├── styles.css             # Styling
│   └── main.js                # Client-side logic
├── tests/                      # Test suite
│   └── test_pipeline.py       # Unit and integration tests
└── sample_data/                # Sample test data
    ├── generate_synthetic.py  # Generate test screenshots
    ├── screenshot_text.png    # Sample with text
    ├── screenshot_mixed.png   # Sample with mixed content
    └── screenshot_profile.png # Sample with face placeholder
```

## Known Limitations & Next Steps

### Current Limitations

1. **OCR Accuracy**: Text detection depends on pytesseract accuracy, which can vary with image quality, fonts, and languages
2. **Face Detection**: MTCNN requires TensorFlow which is heavy; OpenCV cascade fallback is less accurate
3. **Language Support**: Currently optimized for English text only
4. **Processing Speed**: Large images or images with many detections may take several seconds to process
5. **QR Code Dependency**: pyzbar requires system-level zbar library installation

### Planned Improvements

1. **Batch Processing**: Support for processing multiple screenshots at once
2. **Custom Patterns**: Allow users to define custom regex patterns for organization-specific sensitive data
3. **Machine Learning Enhancement**: Fine-tune detection models on user feedback
4. **Mobile Support**: Optimize for mobile screenshot formats and text patterns
5. **Export Options**: Generate PDF reports with redaction summaries and audit logs
6. **Language Expansion**: Support for multiple languages in OCR and NER
7. **Browser Extension**: One-click screenshot capture and redaction
8. **Advanced Redaction**: Smart redaction that maintains document structure

## Dependencies & Fallbacks

The application includes intelligent fallbacks for heavy dependencies:

- **OCR**: Uses pytesseract (lightweight, requires system Tesseract)
- **Face Detection**: Primary: MTCNN, Fallback: OpenCV Haar Cascade
- **NER**: Uses spaCy with en_core_web_sm (can be disabled for lighter operation)

## Privacy & Security

- ✅ No persistent storage of uploaded images
- ✅ Temporary files deleted after processing
- ✅ Sensitive text masked in application logs
- ✅ No external API calls (all processing on-device/server)
- ✅ Configurable detection to minimize false positives

## License

MIT License

## Support

For issues or questions, please open an issue on the repository.

---

**Note**: This is an MVP implementation focused on accuracy and usability. For production use, consider additional security hardening, performance optimization, and thorough testing with real-world data.
