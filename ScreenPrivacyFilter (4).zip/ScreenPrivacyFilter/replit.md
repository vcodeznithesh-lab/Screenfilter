# Screenshot Privacy Filter - Replit Project

## Overview
A privacy-focused web application that detects and redacts sensitive information (PII, faces, QR codes) from screenshots using OCR, NER, and computer vision.

## Project Status
**Created**: November 15, 2025
**Status**: MVP Development Complete
**Framework**: FastAPI + Vanilla JavaScript

## Architecture
- **Backend**: FastAPI (Python 3.11) with uvicorn
- **Detection Pipeline**: 
  - OCR: pytesseract
  - NER: spaCy (en_core_web_sm)
  - Face Detection: MTCNN (fallback to OpenCV)
  - QR Detection: pyzbar
- **Frontend**: HTML5, CSS3, Vanilla JavaScript
- **Image Processing**: OpenCV, Pillow

## Key Features
1. Multi-layer detection (text, faces, QR codes, NER)
2. Three redaction methods (pixelate, blur, black box)
3. Interactive web UI with before/after preview
4. Privacy-first: no permanent storage
5. Comprehensive test suite

## File Structure
- `app.py` - FastAPI server
- `processor.py` - Detection pipeline
- `utils.py` - Helper functions
- `static/` - Frontend files
- `tests/` - Test suite
- `sample_data/` - Synthetic test data

## Running the Project
```bash
# Install dependencies
pip install -r requirements.txt
python -m spacy download en_core_web_sm

# Run server
uvicorn app:app --host 0.0.0.0 --port 5000

# Generate test data
python sample_data/generate_synthetic.py

# Run tests
pytest tests/test_pipeline.py -v
```

## Recent Changes
- Initial project setup
- Implemented core detection pipeline
- Created web UI with drag-drop upload
- Added comprehensive test suite
- Generated synthetic test data

## User Preferences
None specified yet.

## Known Issues
1. Tesseract OCR needs system installation
2. pyzbar requires zbar library
3. MTCNN requires TensorFlow (heavy dependency)

## Next Steps
1. Install system dependencies
2. Configure workflow
3. Test with synthetic data
4. Verify all detection types work correctly
