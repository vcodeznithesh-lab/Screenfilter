"""
Utility functions for Screenshot Privacy Filter.
Handles image preprocessing, bounding box operations, and common helpers.
"""

import cv2
import numpy as np
from typing import List, Tuple, Dict, Any
from PIL import Image
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


def calculate_iou(box1: Tuple[int, int, int, int], box2: Tuple[int, int, int, int]) -> float:
    """
    Calculate Intersection over Union (IoU) between two bounding boxes.
    
    Args:
        box1: Tuple of (x1, y1, x2, y2)
        box2: Tuple of (x1, y1, x2, y2)
    
    Returns:
        IoU value between 0 and 1
    """
    x1_min, y1_min, x1_max, y1_max = box1
    x2_min, y2_min, x2_max, y2_max = box2
    
    # Calculate intersection area
    x_left = max(x1_min, x2_min)
    y_top = max(y1_min, y2_min)
    x_right = min(x1_max, x2_max)
    y_bottom = min(y1_max, y2_max)
    
    if x_right < x_left or y_bottom < y_top:
        return 0.0
    
    intersection_area = (x_right - x_left) * (y_bottom - y_top)
    
    # Calculate union area
    box1_area = (x1_max - x1_min) * (y1_max - y1_min)
    box2_area = (x2_max - x2_min) * (y2_max - y2_min)
    union_area = box1_area + box2_area - intersection_area
    
    return intersection_area / union_area if union_area > 0 else 0.0


def merge_overlapping_boxes(
    boxes: List[Dict[str, Any]], 
    iou_threshold: float = 0.1, 
    padding: int = 6
) -> List[Dict[str, Any]]:
    """
    Merge overlapping bounding boxes based on IoU threshold and add padding.
    
    Args:
        boxes: List of detection dictionaries with 'bbox' key
        iou_threshold: Minimum IoU to consider boxes as overlapping
        padding: Pixels to add around merged boxes
    
    Returns:
        List of merged detection dictionaries
    """
    if not boxes:
        return []
    
    merged = []
    used = set()
    
    for i, box1 in enumerate(boxes):
        if i in used:
            continue
        
        current_bbox = list(box1['bbox'])
        merged_types = {box1['type']}
        merged_texts = [box1.get('text', '')]
        
        for j, box2 in enumerate(boxes[i + 1:], start=i + 1):
            if j in used:
                continue
            
            iou = calculate_iou(tuple(current_bbox), tuple(box2['bbox']))
            
            if iou > iou_threshold:
                # Merge boxes by taking min/max coordinates
                current_bbox = [
                    min(current_bbox[0], box2['bbox'][0]),
                    min(current_bbox[1], box2['bbox'][1]),
                    max(current_bbox[2], box2['bbox'][2]),
                    max(current_bbox[3], box2['bbox'][3])
                ]
                merged_types.add(box2['type'])
                merged_texts.append(box2.get('text', ''))
                used.add(j)
        
        # Add padding
        current_bbox[0] = max(0, current_bbox[0] - padding)
        current_bbox[1] = max(0, current_bbox[1] - padding)
        current_bbox[2] = current_bbox[2] + padding
        current_bbox[3] = current_bbox[3] + padding
        
        merged.append({
            'bbox': current_bbox,
            'type': '+'.join(sorted(merged_types)),
            'text': ' | '.join([t for t in merged_texts if t]),
            'confidence': box1.get('confidence', 1.0)
        })
        used.add(i)
    
    return merged


def preprocess_image(image: np.ndarray, max_dimension: int = 1080) -> np.ndarray:
    """
    Preprocess image by resizing if too large.
    
    Args:
        image: Input image as numpy array
        max_dimension: Maximum width or height
    
    Returns:
        Preprocessed image
    """
    height, width = image.shape[:2]
    
    if height > max_dimension or width > max_dimension:
        scale = max_dimension / max(height, width)
        new_width = int(width * scale)
        new_height = int(height * scale)
        
        logger.info(f"Resizing image from {width}x{height} to {new_width}x{new_height}")
        image = cv2.resize(image, (new_width, new_height), interpolation=cv2.INTER_AREA)
    
    return image


def expand_bbox(bbox: Tuple[int, int, int, int], image_shape: Tuple[int, int], padding: int = 5) -> Tuple[int, int, int, int]:
    """
    Expand bounding box by padding while keeping within image bounds.
    
    Args:
        bbox: (x1, y1, x2, y2)
        image_shape: (height, width)
        padding: Pixels to add on each side
    
    Returns:
        Expanded bounding box
    """
    height, width = image_shape[:2]
    x1, y1, x2, y2 = bbox
    
    x1 = max(0, x1 - padding)
    y1 = max(0, y1 - padding)
    x2 = min(width, x2 + padding)
    y2 = min(height, y2 + padding)
    
    return (x1, y1, x2, y2)


def bbox_from_points(points: List[Tuple[int, int]]) -> Tuple[int, int, int, int]:
    """
    Create axis-aligned bounding box from a list of points.
    
    Args:
        points: List of (x, y) coordinates
    
    Returns:
        Bounding box as (x1, y1, x2, y2)
    """
    if not points:
        return (0, 0, 0, 0)
    
    xs = [p[0] for p in points]
    ys = [p[1] for p in points]
    
    return (min(xs), min(ys), max(xs), max(ys))


def pil_to_cv2(pil_image: Image.Image) -> np.ndarray:
    """Convert PIL Image to OpenCV format."""
    return cv2.cvtColor(np.array(pil_image), cv2.COLOR_RGB2BGR)


def cv2_to_pil(cv2_image: np.ndarray) -> Image.Image:
    """Convert OpenCV image to PIL format."""
    return Image.fromarray(cv2.cvtColor(cv2_image, cv2.COLOR_BGR2RGB))


def mask_sensitive_text(text: str, show_partial: bool = True) -> str:
    """
    Mask sensitive text for logging purposes.
    
    Args:
        text: Original text
        show_partial: Whether to show partial text
    
    Returns:
        Masked text
    """
    if not text or len(text) < 4:
        return "***"
    
    if show_partial:
        return f"{text[:2]}...{text[-2:]}"
    
    return "***"
