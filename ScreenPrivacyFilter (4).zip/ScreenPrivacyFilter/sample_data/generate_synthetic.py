"""
Generate synthetic screenshots with sensitive information for testing.
Creates sample images with text, faces, QR codes for testing the redaction pipeline.
"""

import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageFont
import os


def create_text_screenshot(width=800, height=600):
    """Create a screenshot-like image with sensitive text information."""
    
    # Create white background
    image = np.ones((height, width, 3), dtype=np.uint8) * 255
    
    # Sample sensitive data
    texts = [
        ("Contact Information", 50, 50, 1.2, 3, (0, 0, 0)),
        ("Name: John Smith", 50, 100, 0.8, 2, (50, 50, 50)),
        ("Email: john.smith@example.com", 50, 140, 0.8, 2, (50, 50, 50)),
        ("Phone: +1-555-123-4567", 50, 180, 0.8, 2, (50, 50, 50)),
        ("Address: 123 Main St, New York", 50, 220, 0.8, 2, (50, 50, 50)),
        
        ("Transaction Details", 50, 300, 1.2, 3, (0, 0, 0)),
        ("Amount: $1,234.56", 50, 350, 0.8, 2, (50, 50, 50)),
        ("Transaction ID: TXN-ABC123XYZ", 50, 390, 0.8, 2, (50, 50, 50)),
        ("Card: 4532-1234-5678-9012", 50, 430, 0.8, 2, (50, 50, 50)),
        ("Account Balance: Rs. 45,678.90", 50, 470, 0.8, 2, (50, 50, 50)),
    ]
    
    # Add text to image
    for text, x, y, scale, thickness, color in texts:
        cv2.putText(image, text, (x, y), 
                   cv2.FONT_HERSHEY_SIMPLEX, scale, color, thickness)
    
    return image


def create_mixed_screenshot(width=1000, height=700):
    """Create a complex screenshot with multiple types of sensitive data."""
    
    # Create background with gradient
    image = np.ones((height, width, 3), dtype=np.uint8) * 245
    
    # Add header bar
    cv2.rectangle(image, (0, 0), (width, 80), (63, 81, 181), -1)
    cv2.putText(image, "Banking App Dashboard", (30, 50), 
               cv2.FONT_HERSHEY_SIMPLEX, 1.5, (255, 255, 255), 3)
    
    # User info section
    cv2.rectangle(image, (30, 100), (470, 300), (255, 255, 255), -1)
    cv2.rectangle(image, (30, 100), (470, 300), (200, 200, 200), 2)
    
    user_info = [
        ("Profile Information", 50, 130, 1.0, 2, (0, 0, 0)),
        ("User: Alice Johnson", 50, 170, 0.7, 2, (50, 50, 50)),
        ("Email: alice.j@email.com", 50, 200, 0.7, 2, (50, 50, 50)),
        ("Phone: (555) 987-6543", 50, 230, 0.7, 2, (50, 50, 50)),
        ("Member ID: USR-789456123", 50, 260, 0.7, 2, (50, 50, 50)),
    ]
    
    for text, x, y, scale, thickness, color in user_info:
        cv2.putText(image, text, (x, y), 
                   cv2.FONT_HERSHEY_SIMPLEX, scale, color, thickness)
    
    # Transaction section
    cv2.rectangle(image, (500, 100), (970, 300), (255, 255, 255), -1)
    cv2.rectangle(image, (500, 100), (970, 300), (200, 200, 200), 2)
    
    transaction_info = [
        ("Recent Transaction", 520, 130, 1.0, 2, (0, 0, 0)),
        ("Amount: USD 3,456.78", 520, 170, 0.7, 2, (50, 50, 50)),
        ("Date: 2025-11-15", 520, 200, 0.7, 2, (50, 50, 50)),
        ("TXN: REF-XYZ789ABC", 520, 230, 0.7, 2, (50, 50, 50)),
        ("Balance: $12,345.67", 520, 260, 0.7, 2, (50, 50, 50)),
    ]
    
    for text, x, y, scale, thickness, color in transaction_info:
        cv2.putText(image, text, (x, y), 
                   cv2.FONT_HERSHEY_SIMPLEX, scale, color, thickness)
    
    # Payment info section
    cv2.rectangle(image, (30, 330), (970, 500), (255, 255, 255), -1)
    cv2.rectangle(image, (30, 330), (970, 500), (200, 200, 200), 2)
    
    payment_info = [
        ("Payment Method", 50, 360, 1.0, 2, (0, 0, 0)),
        ("Card Number: 5234-8901-2345-6789", 50, 400, 0.7, 2, (50, 50, 50)),
        ("Expiry: 12/28    CVV: 123", 50, 430, 0.7, 2, (50, 50, 50)),
        ("SSN: 123-45-6789", 50, 460, 0.7, 2, (50, 50, 50)),
    ]
    
    for text, x, y, scale, thickness, color in payment_info:
        cv2.putText(image, text, (x, y), 
                   cv2.FONT_HERSHEY_SIMPLEX, scale, color, thickness)
    
    # Add QR code placeholder (simplified representation)
    qr_size = 120
    qr_x, qr_y = 800, 350
    
    # Create checkerboard pattern for QR code
    cell_size = 15
    for i in range(0, qr_size, cell_size):
        for j in range(0, qr_size, cell_size):
            if (i // cell_size + j // cell_size) % 2 == 0:
                cv2.rectangle(image, (qr_x + i, qr_y + j), 
                            (qr_x + i + cell_size, qr_y + j + cell_size), 
                            (0, 0, 0), -1)
    
    cv2.putText(image, "Scan to Pay", (qr_x, qr_y - 10), 
               cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 0, 0), 2)
    
    # Add footer
    cv2.putText(image, "Confidential - For Account Holder Only", (30, height - 30), 
               cv2.FONT_HERSHEY_SIMPLEX, 0.8, (150, 150, 150), 2)
    
    return image


def create_simple_face_placeholder(width=600, height=400):
    """Create a simple image with a face placeholder (circle)."""
    
    image = np.ones((height, width, 3), dtype=np.uint8) * 240
    
    cv2.putText(image, "User Profile", (200, 50), 
               cv2.FONT_HERSHEY_SIMPLEX, 1.2, (0, 0, 0), 3)
    
    # Draw a simple face representation (circle for head)
    center = (width // 2, height // 2)
    radius = 80
    
    # Face circle
    cv2.circle(image, center, radius, (255, 220, 180), -1)
    cv2.circle(image, center, radius, (0, 0, 0), 2)
    
    # Eyes
    cv2.circle(image, (center[0] - 30, center[1] - 20), 10, (0, 0, 0), -1)
    cv2.circle(image, (center[0] + 30, center[1] - 20), 10, (0, 0, 0), -1)
    
    # Smile
    cv2.ellipse(image, (center[0], center[1] + 10), (40, 30), 0, 0, 180, (0, 0, 0), 2)
    
    # Add name below
    cv2.putText(image, "Sarah Williams", (center[0] - 120, height - 80), 
               cv2.FONT_HERSHEY_SIMPLEX, 1.0, (0, 0, 0), 2)
    cv2.putText(image, "sarah.w@company.com", (center[0] - 150, height - 50), 
               cv2.FONT_HERSHEY_SIMPLEX, 0.8, (50, 50, 50), 2)
    
    return image


def main():
    """Generate all synthetic test images."""
    
    # Create output directory
    os.makedirs('sample_data', exist_ok=True)
    
    print("Generating synthetic test screenshots...")
    
    # Generate images
    images = {
        'sample_data/screenshot_text.png': create_text_screenshot(),
        'sample_data/screenshot_mixed.png': create_mixed_screenshot(),
        'sample_data/screenshot_profile.png': create_simple_face_placeholder(),
    }
    
    # Save images
    for filename, image in images.items():
        cv2.imwrite(filename, image)
        print(f"✓ Created {filename}")
    
    print(f"\nGenerated {len(images)} test screenshots in sample_data/")
    print("You can use these images to test the privacy filter.")


if __name__ == '__main__':
    main()
