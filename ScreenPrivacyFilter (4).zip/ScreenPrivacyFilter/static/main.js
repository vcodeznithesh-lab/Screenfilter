// Screenshot Privacy Filter - Frontend JavaScript

let selectedFile = null;
let originalImageData = null;

// DOM Elements
const uploadArea = document.getElementById('uploadArea');
const fileInput = document.getElementById('fileInput');
const processBtn = document.getElementById('processBtn');
const previewSection = document.getElementById('previewSection');
const originalImage = document.getElementById('originalImage');
const redactedImage = document.getElementById('redactedImage');
const loadingOverlay = document.getElementById('loadingOverlay');
const detectionCount = document.getElementById('detectionCount');
const processingTime = document.getElementById('processingTime');
const detectionsContent = document.getElementById('detectionsContent');
const downloadBtn = document.getElementById('downloadBtn');
const resetBtn = document.getElementById('resetBtn');

// Detection options
const detectText = document.getElementById('detectText');
const detectFaces = document.getElementById('detectFaces');
const detectQR = document.getElementById('detectQR');
const detectNER = document.getElementById('detectNER');
const redactionMethod = document.getElementById('redactionMethod');

// Event Listeners
uploadArea.addEventListener('click', () => fileInput.click());
fileInput.addEventListener('change', handleFileSelect);
processBtn.addEventListener('click', processImage);
downloadBtn.addEventListener('click', downloadRedactedImage);
resetBtn.addEventListener('click', resetApp);

// Drag and drop
uploadArea.addEventListener('dragover', (e) => {
    e.preventDefault();
    uploadArea.classList.add('drag-over');
});

uploadArea.addEventListener('dragleave', () => {
    uploadArea.classList.remove('drag-over');
});

uploadArea.addEventListener('drop', (e) => {
    e.preventDefault();
    uploadArea.classList.remove('drag-over');
    
    const files = e.dataTransfer.files;
    if (files.length > 0) {
        handleFile(files[0]);
    }
});

function handleFileSelect(e) {
    const file = e.target.files[0];
    if (file) {
        handleFile(file);
    }
}

function handleFile(file) {
    // Validate file type
    if (!file.type.startsWith('image/')) {
        alert('Please select an image file');
        return;
    }

    // Validate file size (5 MB)
    const maxSize = 5 * 1024 * 1024;
    if (file.size > maxSize) {
        alert('File size exceeds 5 MB limit');
        return;
    }

    selectedFile = file;
    
    // Preview the original image
    const reader = new FileReader();
    reader.onload = (e) => {
        originalImageData = e.target.result;
        originalImage.src = originalImageData;
    };
    reader.readAsDataURL(file);

    // Enable process button
    processBtn.disabled = false;
    
    // Update upload area text
    const uploadContent = uploadArea.querySelector('.upload-content');
    uploadContent.innerHTML = `
        <svg class="upload-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" 
                  d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
        <h3>✓ ${file.name}</h3>
        <p class="file-info">Click to select a different file</p>
    `;
}

async function processImage() {
    if (!selectedFile) return;

    const startTime = performance.now();

    // Show preview section and loading
    previewSection.style.display = 'block';
    loadingOverlay.style.display = 'flex';
    redactedImage.src = '';

    // Scroll to preview
    previewSection.scrollIntoView({ behavior: 'smooth', block: 'start' });

    try {
        // Prepare form data
        const formData = new FormData();
        formData.append('file', selectedFile);
        formData.append('detect_text', detectText.checked);
        formData.append('detect_faces', detectFaces.checked);
        formData.append('detect_qr', detectQR.checked);
        formData.append('detect_ner', detectNER.checked);
        formData.append('redaction_method', redactionMethod.value);
        formData.append('return_image', 'false');

        // Send request
        const response = await fetch('/api/redact', {
            method: 'POST',
            body: formData
        });

        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.detail || 'Processing failed');
        }

        const result = await response.json();
        
        // Calculate processing time
        const endTime = performance.now();
        const duration = ((endTime - startTime) / 1000).toFixed(2);

        // Update UI
        redactedImage.src = result.redacted_image;
        detectionCount.textContent = result.num_detections;
        processingTime.textContent = `${duration}s`;

        // Display detections
        displayDetections(result.detections);

        // Hide loading overlay
        loadingOverlay.style.display = 'none';

    } catch (error) {
        console.error('Error processing image:', error);
        alert(`Error: ${error.message}`);
        loadingOverlay.style.display = 'none';
    }
}

function displayDetections(detections) {
    detectionsContent.innerHTML = '';

    if (detections.length === 0) {
        detectionsContent.innerHTML = '<p style="color: #10b981; font-weight: 600;">✓ No sensitive information detected!</p>';
        return;
    }

    // Group detections by type
    const grouped = {};
    detections.forEach(det => {
        const type = det.type;
        if (!grouped[type]) {
            grouped[type] = [];
        }
        grouped[type].push(det);
    });

    // Create badges
    Object.entries(grouped).forEach(([type, items]) => {
        const badge = document.createElement('div');
        badge.className = 'detection-badge';
        badge.innerHTML = `
            <span class="detection-type">${formatDetectionType(type)}</span>
            <span class="detection-confidence">×${items.length}</span>
        `;
        detectionsContent.appendChild(badge);
    });
}

function formatDetectionType(type) {
    const typeMap = {
        'email': '📧 Email',
        'phone': '📱 Phone',
        'currency': '💰 Currency',
        'amount': '💵 Amount',
        'transaction_id': '🔖 Transaction ID',
        'credit_card': '💳 Credit Card',
        'ssn': '🆔 SSN',
        'face': '👤 Face',
        'qr_qrcode': '📱 QR Code',
        'qr_code128': '📊 Barcode',
        'ner_person': '👤 Person Name',
        'ner_gpe': '📍 Location',
        'ner_org': '🏢 Organization'
    };

    return typeMap[type] || type.toUpperCase();
}

function downloadRedactedImage() {
    if (!redactedImage.src) return;

    // Create a temporary link and trigger download
    const link = document.createElement('a');
    link.href = redactedImage.src;
    link.download = `redacted_${selectedFile.name.split('.')[0]}.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}

function resetApp() {
    selectedFile = null;
    originalImageData = null;
    fileInput.value = '';
    processBtn.disabled = true;
    previewSection.style.display = 'none';
    
    // Reset upload area
    const uploadContent = uploadArea.querySelector('.upload-content');
    uploadContent.innerHTML = `
        <svg class="upload-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" 
                  d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
        </svg>
        <h3>Drop screenshot here or click to upload</h3>
        <p class="file-info">Maximum file size: 5 MB</p>
    `;

    // Scroll to top
    window.scrollTo({ top: 0, behavior: 'smooth' });
}
